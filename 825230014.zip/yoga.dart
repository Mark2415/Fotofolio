import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Health App UI',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto',
      ),
      home: const YogaPage(), // Mengarahkan ke halaman Yoga
      debugShowCheckedModeBanner: false,
    );
  }
}

class YogaPage extends StatefulWidget {
  const YogaPage({super.key});

  @override
  State<YogaPage> createState() => _YogaPageState();
}

class _YogaPageState extends State<YogaPage> {
  String currentUserName = "Mailbin 📪";
  int _bottomNavIndex = 0;

    // Fungsi untuk mendapatkan salam
  String _getGreeting() {
    final hour = DateTime.now().hour;
    
    // 00:00 - 10:59 -> Pagi
    if (hour >= 0 && hour < 11) {
      return 'Good Morning';
    } 
    // 11:00 - 14:59 -> Siang
    else if (hour >= 11 && hour < 15) {
      return 'Good Afternoon';
    } 
    // 15:00 - 23:59 -> Sore/Malam
    else if (hour >= 15 && hour < 24) {
      return 'good evening';
    } 
    // Default -> Have a good day
    else {
      return 'Have a good day';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeaderAndTabs(),
            _buildYogaTimerAndMusic(),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildHeaderAndTabs() {
    return Container(
      padding: const EdgeInsets.only(top: 60, bottom: 20),
      decoration: const BoxDecoration(
        color: Color(0xFFF9C8A9),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _getGreeting(),
                  style: const TextStyle(color: Colors.white, fontSize: 22),
                ),
                Text(
                  currentUserName,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.8),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const TextField(
                    decoration: InputDecoration(
                      icon: Icon(Icons.search, color: Colors.grey),
                      hintText: 'Search',
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'Yoga',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildHeaderTabItem(icon: Icons.home, label: 'Home'),
              _buildHeaderTabItem(icon: Icons.restaurant_menu, label: 'Diet Plan'),
              _buildHeaderTabItem(icon: Icons.fitness_center, label: 'Exercises'),
              _buildHeaderTabItem(icon: Icons.medical_services_outlined, label: 'Medical Tips'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderTabItem({required IconData icon, required String label}) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.3),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: Colors.white, size: 24),
        ),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 12))
      ],
    );
  }

  Widget _buildYogaTimerAndMusic() {
    return Container(
      margin: const EdgeInsets.all(24.0),
      padding: const EdgeInsets.all(20.0),
      decoration: BoxDecoration(
        color: const Color(0xFFF9F0BE),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 2,
            blurRadius: 8,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text(
              'STAND BY',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black54,
                letterSpacing: 2,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildTimeAdjustButton(label: '-1S'),
              _buildTimeAdjustButton(label: '-1M'),
              _buildTimeAdjustButton(label: '-1H'),
              const SizedBox(width: 4), // DIKECILKAN
              _buildTimerDisplay(),
              const SizedBox(width: 4), // DIKECILKAN
              _buildTimeAdjustButton(label: '+1H'),
              _buildTimeAdjustButton(label: '+1M'),
              _buildTimeAdjustButton(label: '+1S'),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.refresh, color: Color(0xFF8A2BE2)),
          ),
          const SizedBox(height: 15),
          Container(
            width: 100,
            height: 35,
            decoration: BoxDecoration(
              color: const Color(0xFF8A2BE2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Center(
              child: Text(
                'Stop',
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(height: 30),
          const Text(
            'Waiting for music info',
            style: TextStyle(color: Colors.black54, fontSize: 14),
          ),
          const SizedBox(height: 10),
          _buildMusicPlayerControls(),
        ],
      ),
    );
  }

  // WIDGET DENGAN UKURAN YANG LEBIH KECIL
  Widget _buildTimeAdjustButton({required String label}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2), // DIKECILKAN
      width: 34,  // DIKECILKAN
      height: 34, // DIKECILKAN
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
          ),
        ],
      ),
      child: Center(
        child: Text(
          label,
          style: const TextStyle(fontSize: 12, color: Colors.black54), // Font dikecilkan
        ),
      ),
    );
  }

  // WIDGET DENGAN UKURAN YANG LEBIH KECIL
  Widget _buildTimerDisplay() {
    return Container(
      width: 90,  // DIKECILKAN
      height: 40, // DIKECILKAN
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
          ),
        ],
      ),
      child: const Center(
        child: Text(
          '00:00:00',
          style: TextStyle(
            fontSize: 16, // Font dikecilkan
            fontWeight: FontWeight.bold,
            color: Color(0xFF8A2BE2),
          ),
        ),
      ),
    );
  }

  Widget _buildMusicPlayerControls() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 3,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Icon(Icons.queue_music, color: Colors.grey[700], size: 28),
          Icon(Icons.skip_previous, color: Colors.grey[700], size: 36),
          Icon(Icons.play_arrow, color: Colors.grey[700], size: 36),
          Icon(Icons.skip_next, color: Colors.grey[700], size: 36),
          Icon(Icons.volume_up, color: Colors.grey[700], size: 28),
        ],
      ),
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: _bottomNavIndex,
      onTap: (index) {
        setState(() {
          _bottomNavIndex = index;
        });
      },
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.white,
      selectedItemColor: const Color(0xFF8A2BE2),
      unselectedItemColor: Colors.grey,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.today_outlined),
          activeIcon: Icon(Icons.today),
          label: 'Today',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.settings_outlined),
          activeIcon: Icon(Icons.settings),
          label: 'Settings',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.event_outlined),
          activeIcon: Icon(Icons.event),
          label: 'Tomorrow',
        ),
      ],
    );
  }
}